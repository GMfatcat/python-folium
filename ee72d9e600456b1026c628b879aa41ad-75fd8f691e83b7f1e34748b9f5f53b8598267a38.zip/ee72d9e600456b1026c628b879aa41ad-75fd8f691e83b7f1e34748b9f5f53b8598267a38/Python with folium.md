**HOW TO CREATE A MAP BY PYTHON?**

![](https://i.imgur.com/0z4IaS2.jpg)


*by GM MUMU*

---



# Python with folium
---

**下載 *Anaconda 3***

**搜尋Anaconda**


**下載安裝**
     
**若沒有python也要載一下(version3.5/3.6)** 

----


> 英文補給站: python 是指蟒蛇 ,而Anaconda是指森蚺[color=#c4db60]

 ---
 **英文造句時間:**
**~~Do you want to see my anaconda?~~**


---




# 2.安裝 ==*folium*== 套件
---
**開啟 Anaconda Prompt 來安裝 ==*folium*==**

**語法如下:**
```python=
pip3 install folium
```

**安裝好後就將Prompt關掉**


---


# 3.來畫圖囉
---
*    開啟 *juypter notebook*


----


**小黑窗不能關掉喔!!!**


----


*    按下左上角的new -> python3
*    執行方法: ==shift + enter==(重要!!!)
*    單行註解 : #abc
*    多行註解 : '''abc'''
*    在新的頁面中線將untitled 按一下: 可以改名


----


```python=
import folium

fmap = folium.Map(location=[22.998642,120.219831], zoom_start=16)

fmap
```
>座標地點可以自己找
>測量系館大概是[22.998642,120.219831][color=#480575]


----


**也可以將製作好的地圖存成 *html*
  直接用瀏覽器開啟**
  
```python=
fmap.save('map.html')#檔名可自己改,目前是map
```

---

# 4.加入Marker囉!!


----


什麼是 Marker ?

地圖上的標記(ex.google map 小紅點)


----


地圖上面只有地名很無單調


我們來加一下marker八!!!


----


Marker可以標註點

我們也可以使用 *popout* 來顯示文字


----

```python=
fmap.add_child(folium.Marker
(location = [22.998642,120.219831],
popout = '成大測量系'))
```

**打完之後就 *shift + enter* 看一下吧~**


----


**應該會長類似這樣**
![](https://i.imgur.com/WCVMjRH.jpg)


---


# 5.自訂Marker color 


----


但是,當我們想要加入更多的點怎麼辦呢?

可以透過不同的變數來存取喔!!!

like this
```python=
    m1 = fmap.add_child(folium.Marker # m1 = 變數名稱
    (location = [22.998642,120.219831],
    popout = '成大測量系'),
    color = 'green') # 透過加入color來區分color間的不同
```


----


**color 怎麼改阿?**

*    方法一
---
```python=
    color = 'green' #使用內建支援色彩
    #色彩支援如下(真的不多)
[‘red’,‘blue’,‘green’,‘purple’,
‘orange’,‘darkred’,’lightred’,
‘beige’, ‘darkblue’, ‘darkgreen’,
‘cadetblue’, ‘darkpurple’, ‘white’,
‘pink’,‘lightblue’, ‘lightgreen’, 
‘gray’, ‘black’, ‘lightgray’]

```

----


*    方法二
---
```python=
     #使用色碼表查詢,ex:#FFFF77
     #輸入16進位色碼
     color = '#9999FF'

```

[**色碼表**](https://www.toodoo.com/db/color.html)


---


# 6.自訂 Marker icon


----

*    方法一
---
**使用內建icon**
```python=

m3 = folium.Marker(location=[35.715092, 139.796666],
    popup='Asakusa Temple',
    icon=folium.Icon(icon='info-sign' ,color ='beige'))
    #info-sign 為內建支援icon
```


----


注意: 一個 *Marker()* 裡面只能有一個 *color* 

不能icon裡面一個 *color* ,外面再設立一個!!!
```python=
m3 = folium.Marker(location=[35.715092, 139.796666],
    popup='Asakusa Temple',
    icon=folium.Icon(icon='info-sign' ,color ='beige'),
    color = 'blue') #這行是錯的

```


----


*    方法二

**使用外部icon**

**使用 font awesome**

**1.搜尋 font awesome**

**2.版本相容問題,請使用舊版version 4**

**舊版連結在官網最下方(oid version 4.7),或[點我](https://fontawesome.com/v4.7.0/)**


----


**點選 icons -> all icons **

**選擇你想要的icons**

**以 *paper - plane* 為例([點我](https://fontawesome.com/v4.7.0/icon/paper-plane))**

**進入頁面後應該會看到**

==fa-paper-plane==


----


**這邊的 *fa* 是 *prefix(前綴修飾)(html 語法)***

***paper-plane* 則是 *icon style***

```python=
m2 = folium.Marker(location=[35.707595, 139.795530],
        popup='Hotel',
        icon=folium.Icon(icon='paper - plane',#Icon類型
        prefix='fa')) # 使用Font Awesome Icons
```
----
**你應該會看到**
![](https://i.imgur.com/o444qsi.jpg)


----


**當然這邊的 *marker* 也是可以改顏色**
```python=
m2 = folium.Marker(location=[35.707595, 139.795530],
        popup='Hotel',
        icon=folium.Icon(icon='paper - plane',#Icon類型
        color = 'green',
        prefix='fa')) # 使用Font Awesome Icons

```


----
**變綠色囉!!!**
![](https://i.imgur.com/pIvG3Ly.jpg)


---


# 7.Circle & Polyline


----


**地圖上化緣**
![](https://i.imgur.com/AKIb7AV.jpg)


----


**地圖上畫圓**

**使用 *Circle( )***
```python=
center_pos = [35.709635, 139.810851]
fmap.add_child(folium.Circle(location=center_pos,
                             color='red', # Circle 顏色
                             radius=500, # Circle 寬度
                             fill=True, # 填滿中間區域
                             fill_opacity=0.7 # 設定透明度:1是完全不透
                             ))

```


----


**多邊形是由很多線和點組成**

**先給出數個點座標,形成陣列**

**接著使用 *Polyline( )* 連線**


----


```python=
points = [[35.709635, 139.810851],
          [35.707595, 139.795530],
          [35.715092, 139.796666]]

fmap.add_child(folium.PolyLine(locations=points,#座標
                weight=8, # 線條寬度
                color = '#9999FF')) # 顏色
```


----


**成圖:**
![](https://i.imgur.com/9SZYQ6E.jpg)


---


# 8.迷你地圖


----


**我們可以藉由 *folium plugin* 來引入迷你地圖**

**回到最初 *import folium* 下方打上**
```python=
    from folium.plugins import MiniMap
```
**接著指定變數並加入地圖**
```python=
    minimap = MiniMap()
    fmap.add_child(child = minimap)
```


---


# 9.Minimap Control


----


*    **摺疊(收起來)**
*    **尺寸**
*    **縮放比例**
*    **換底圖**


----


**摺疊(收起來)**
```python=
minimap = MiniMap(toggle_display=True)
```
**尺寸**
```python=
minimap = MiniMap(width=400, height=100)
```
**縮放比例**
```python=
minimap = MiniMap(zoom_level_offset=-8)
```
**換底圖**
```python=
minimap = MiniMap(tile_layer='Stamen Toner')
```


----


**提供一些可以換的底圖**

**[看網站](https://deparkes.co.uk/2016/06/10/folium-map-tiles/)**

*    statemanwatercolor
*    cartodbpositron
*    cartodbdark_matter
*    stamenterrain


---


## 10.Measurementcontrol ##


----


**回到最初繼續 *import***

```python=
from folium.plugins import MeasureControl
```
**將量測功能加入地圖**
```python=
fmap.add_child(MeasureControl())#量測地圖功能加入
```


----


**出現這個就成功了,直接用吧!!!**
![](https://i.imgur.com/z2BmLof.jpg)


----

**可以量直線距離,面積
量完之後還可以 *center on it*
超棒的八八~**


---


# 11.點點不見了!?


----


***請大家先將自己的地圖縮小
   直到看到世界地圖***

***然後環球一圈八***

***觀察一下自己設的點還在不在***


----


***若想要在環遊世界後還要保存自己的 *Marker****
***就加上這句八:***
```python=
world_copy_jump=True
```
***加在那裡ㄋ?***
```python=
fmap = folium.Map(
location=[35.709635, 139.810851],
zoom_start = 15,
world_copy_jump=True,)# 建立地圖與設定位置
```


----


***加完之後在環遊世界一次看看吧~***

***folium 地圖的基礎應用就到這邊囉!***

***下一章是 *heatmap****


---



# 12.heatmap


----


***這邊比較難所以就不一一講解***

***基本概念就是地圖資料 + 時間  = 會動的地圖***


----



***因為沒有原始資料
   所以使用亂數資料***
   

----


```python=
import folium # 匯入 folium 套件
import numpy as np #python 的數學庫
from folium.plugins import HeatMap

fmap = folium.Map(location=[35.712326, 139.804037], zoom_start=12)

# 建立隨機資料
data = (np.random.normal(size=(100, 3)) * 0.02 *
        np.array([[1, 1, 1]]) +
        np.array([[35.712326, 139.804037, 1]])).tolist()
#normal() 是指正態分布,裡面吃三個參數(loc(float),scale(float),size(int 或者整数元组))
#相關資料可以看以下連結
fmap.add_child(HeatMap(data=data))
```
[np.normal](https://blog.csdn.net/huanhuan_Coder/article/details/80762208)


----


**大家可以 *shift + enter* 一下**

**會發現出現heatmap 了,但是不會動**

**Why????**


----


***想知道的話請留言告訴小編
   小編收到留言後會 inbox 給您喔***
   

----


**請 import HeatMapWIthTime**

```python=
import numpy as np
from folium.plugins import HeatMapWithTime

center_pos = [35.712326, 139.804037]

# 使用 numpy 建立初始資料
initial_data = (np.random.normal(size=(200, 2)) *
                np.array([[0.07, 0.07]]) +
                np.array([center_pos]))

# 建立連續資料
data = [initial_data.tolist()]
for i in range(80):
    data.append((data[i] + np.random.normal(size=(200, 2)) * 0.122).tolist())

fmap = folium.Map(center_pos, zoom_start=11)
fmap.add_child(HeatMapWithTime(data)) # 顯示連續熱度圖

```


----


**What do you see now???**

**可以調整 fps, 控制循環, 正反播放, 快進退**


---


# 想學更多


----


**以下網站可以幫助你**

**前提是看得懂英文**

1. [Stack Overflow](https://stackoverflow.com)
2. [folium map tutorial](http://nbviewer.jupyter.org/github/python-visualization/folium/tree/master/examples/)
3. [Cheng-Shiang Li's Blog](http://blog.yeshuanova.com)

**本次教學內容幾乎都在以上連結可找到,感謝他們**
###### tags: `python`
###### tags: `folium`


---


# End

**edited by MUMU,2018/12/24**
















